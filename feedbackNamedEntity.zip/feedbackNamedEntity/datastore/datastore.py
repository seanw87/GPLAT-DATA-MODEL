#!/usr/bin/env python
# -*- coding:utf-8 -*-

import datetime
import time
import json
from elasticsearch import Elasticsearch

es = Elasticsearch(hosts=["117.184.40.160:9200"], timeout=5000)

def getDiffDays():
    today = datetime.date.today()
    oneday = datetime.timedelta(days=1)
    someday = today - oneday
    return someday
def getYesterdayMonth():
    someday = getDiffDays()
    yesterday_month = someday.strftime("%m")
    yesterday_month = str(int(yesterday_month))
    yesterday_month_fmt = someday.strftime("%Y") + "." + yesterday_month
    # return "2020.3"
    return yesterday_month_fmt
def getYesterday():
    someday = getDiffDays()
    yesterday = someday.strftime("%Y.%m.%d")
    return yesterday
def getYesterdayTs():
    someday = getDiffDays()
    yesterday_ts = time.mktime(time.strptime(someday.strftime("%Y-%m-%d %H:%M:%S"), "%Y-%m-%d %H:%M:%S"))
    return yesterday_ts

def get_esindex():
    """
    read config info
    """
    es_index = "qiuqiu-game-report-" + getYesterdayMonth()
    print(es_index)
    return es_index

esresult = []
def get_yesterday_feedbacks():
    yesterday_start_ts = getYesterdayTs()
    yesterday_end_ts = yesterday_start_ts + 24*3600 - 1

    global esresult

    es_index = get_esindex()

    q_body = {
        "query":{
            "bool":{
                "must": [
                    {
                        "range":{
                            "submit_time": {
                                "gte": yesterday_start_ts,
                                "lte": yesterday_end_ts,
                            }
                        }
                    }
                ]
            }
        },
        "from": 0,
        "size": 10000
    }
    res = es.search(index=es_index, body=q_body)

    for item in res['hits']['hits']:
        esresult.append(item["_source"])

    return esresult

def update_yesterday_feedbacks_keyws(keyws):
    es_index = get_esindex()

    upacts = ""
    for item in keyws:
        index = {
            "update": {"_index": es_index, "_type": "report", "_id": item["id"]}
        }
        act = {
            "doc": {"keyws": item["keyws"]}
        }
        upacts += json.dumps(index) + "\n" + json.dumps(act) + "\n"

    print("update_yesterday_feedbacks_keyws", es.bulk(upacts, index=es_index, doc_type="report"))


if __name__ == '__main__':
    get_yesterday_feedbacks()
    print(esresult)