#!/usr/bin/env python
# -*- coding:utf-8 -*-
import math
import re
import pandas as pd
from pyhanlp import *

sys.path.append(os.path.join(os.path.dirname(__file__), "datastore"))
import datastore as datastore

if __name__ == "__main__":
    # hanlp\Lib\site-packages\pyhanlp\static\hanlp.properties 在CustomDictionaryPath变量中添加自定义字典路径
    # print(HanLP.segment("球球大作战生存道具赛"))
    #
    # text = '生存道具赛中存在很多bug，明明不是危险区的地方，却有危险区的颜色，导致进去之后看不清路，建议优化一下生存道具赛，我截了张图片。右上角显示我在安全区内，但是我的左边是危险区。'
    # text = '为什么 抽到没了'
    #
    # reg = "[^0-9A-Za-z\u4e00-\u9fa5]"
    # text_sentense = re.sub("\s+", " ", re.sub(reg, " ", text))
    # # text_without_blank = re.sub(reg, "", text)
    #
    # text_segment = HanLP.segment(text)
    # text_terms_word = []
    # text_terms_nature = []
    # for term in text_segment:
    #     text_terms_word.append(str(term.word).strip())
    #     text_terms_nature.append(str(term.nature).strip())
    # data = {'word': text_terms_word,
    #         'nature': text_terms_nature}
    # df = pd.DataFrame(data)
    # print(df[df.nature!="w"])
    #
    # word_length = len(df[df.nature!="w"])
    # sentense_length = len(text_sentense.split(" "))
    # print("处理后总长度： " + str(len(text_sentense)) + ", 处理后词数: " + str(word_length) + ", 处理后句数: " +
    #       str(sentense_length) + ", 处理后文本: " + text_sentense)
    # word_len = min(math.ceil(word_length/5), 5)
    # print("word_len: " + str(word_len))
    # sentense_len = min(math.ceil(sentense_length/5), 8)
    # print("sentense_len: " + str(sentense_len))
    # print(HanLP.extractKeyword(text, word_len))
    # print(HanLP.extractSummary(text, sentense_len))
    # exit(0)

    # SEQUENCE_MAX_LEN = 50
    # recognizer = hanlp.load(hanlp.pretrained.ner.MSRA_NER_BERT_BASE_ZH)
    # content = list('为什么我上赛季没有赛季结算？你们好好修复一下行么？求求你们了，我对这游戏算是没有任何热情了！今早上登号什么也没有，平白无故掉到白金，我还以为有人打我号，后来我才想起赛季结束了，但是为什么我连赛季结束后新赛季开启的提示都没有？难道是巨人偏心？还是游戏bug？不管是什么问题，你们都要给我一个交代，就想着钱？不把你们的破服务器修修？我换了很多个号，见证了球球的成长.强盛与衰败。现在越来越多的玩家退游了，而你们一点措施也没有（在我看来，也许不止是我），还有最近几天出的球鞋活动，跟拼多多似的，你们能不能走点心？就这方法能拉来多少新球宝？而你们就只会一而再再而三的推辞，你们真的就是不管不顾这游戏了？你们就只是对充值方面有兴趣，而关于其他的，你们又会有什么措施呢？你们想把球球恢复原来的强盛，就不要做黑心官方，黑心商家，黑心团体，黑心个人。把游戏恢复到2016的样子，球球将会大火信不信由你们。')
    # content = list('更新之后版本特别卡')
    # list_len = math.ceil(len(content)/SEQUENCE_MAX_LEN)
    # content_list = []
    # for i in range(list_len):
    #     print("".join(content[i * SEQUENCE_MAX_LEN : i * SEQUENCE_MAX_LEN + SEQUENCE_MAX_LEN]))
    #     content_list.append(content[i * SEQUENCE_MAX_LEN : i * SEQUENCE_MAX_LEN + SEQUENCE_MAX_LEN])
    #
    # print(recognizer(content_list))
    # exit(0)
    # print(recognizer(content))
    # exit(0)

    reg = "[^0-9A-Za-z\u4e00-\u9fa5]"

    esresult = datastore.get_yesterday_feedbacks()

    res_keyws = []
    for item in esresult:
        itemid = item["id"]
        text = item['desc']

        keyws = []

        text_sentense = re.sub("\s+", " ", re.sub(reg, " ", text)).strip()
        sentense_length = len(text_sentense.split(" "))

        print("处理后总长度： " + str(len(text_sentense)) + ", 处理后句数: " +
              str(sentense_length) + ", 处理后文本: " + text_sentense)

        if len(text_sentense) == 0:
            continue

        # 如果句数>3，则提取关键句子
        if sentense_length > 3:
            sentense_len = min(math.ceil(sentense_length / 5), 8)
            print("高亮句数: " + str(sentense_len))
            result = HanLP.extractSummary(text, sentense_len)
        else:
            text_segment = HanLP.segment(text)
            text_terms_word = []
            text_terms_nature = []
            for term in text_segment:
                text_terms_word.append(str(term.word).strip())
                text_terms_nature.append(str(term.nature).strip())
            data = {'word': text_terms_word,
                    'nature': text_terms_nature}
            df = pd.DataFrame(data)
            # print(df[df.nature != "w"])
            word_length = len(df[df.nature != "w"])
            print("处理后词数: " + str(word_length))
            word_len = min(math.ceil(word_length / 5), 5)
            print("高亮词数: " + str(word_len))

            result = HanLP.extractKeyword(text, word_len)

        for res in result:
            keyws.append(str(res))

        res_keyws.append({
            "id": itemid,
            "keyws": "|".join(keyws)
        })

    datastore.update_yesterday_feedbacks_keyws(res_keyws)
