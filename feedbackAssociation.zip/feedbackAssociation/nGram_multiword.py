import itertools
import os
import pandas as pd
from sklearn.utils import shuffle

path = "./data/"

tuple_rank = {}

def load_stop_words():
    """
    加载停用词
    :return:
    """
    with open(os.path.join(path, "stopwords_overall.txt"), encoding="utf-8") as f:
        stopwords = f.read().split("\n")
        return stopwords

def load_stop_wordstuple():
    """
    加载停用词元组
    :return:
    """
    with open(os.path.join(path, "stopwordstpl.txt"), encoding="utf-8") as f:
        stopwordstpl = f.read().split("\n")
        return stopwordstpl

def load_feedbacks():
    """
    加载游戏内反馈
    """
    pd_all = pd.read_csv(os.path.join(path, "qiuqiu-report-2020.04.12"), sep='#')
    pd_all = shuffle(pd_all)
    # print(pd_all.head())
    print(pd_all.shape)
    pd_all = pd_all[pd.notnull(pd_all.ix[:, 18])]
    feedbacks = pd_all.ix[:, 18]
    return feedbacks


def get_feedbacks_tuple(fbSegs, r):
    word_tuples = itertools.combinations(fbSegs, r)
    # print(list(word_tuples))
    for word_tuple in word_tuples:
        # print(word_tuple)
        ifcontinue = False
        for word in word_tuple:
            if word in stop_words or word.strip() == "":
                ifcontinue = True


        if ifcontinue:
            continue
        else:
            word_tuple_fmt = "_".join(word_tuple)
            # print(word_tuple_fmt)

            if word_tuple_fmt not in tuple_rank:
                tuple_rank[word_tuple_fmt] = 1
            else:
                tuple_rank[word_tuple_fmt] += 1


if __name__ == "__main__":
    stop_words = load_stop_words()
    stop_wordstuple = load_stop_wordstuple()
    feedbacks = load_feedbacks()
    feedbacks = feedbacks.drop_duplicates()
    print("去重后反馈量：" + str(len(feedbacks)))
    tuple_len = 1

    for feedback in feedbacks:
        fb_segs = feedback.split("|")
        fb_segs = pd.Series(fb_segs).drop_duplicates(keep='first').tolist()
        get_feedbacks_tuple(fb_segs, tuple_len)

    # for word_tuple in tuple_rank:
    #     print(word_tuple)
    #     print(" rank: " + str(tuple_rank[word_tuple]))

    tuple_rank_pd = pd.DataFrame.from_dict(tuple_rank, orient='index',
                                           columns=['rank']).sort_values('rank', inplace=False, ascending=False)
    # print(tuple_rank_pd.head(100))

    tuple_rank_pd.to_csv(os.path.join(path, "feedbacks_tuple_rank_len" + str(tuple_len) + ".csv"), encoding="utf-8")