import os
import pandas as pd
from sklearn.utils import shuffle

path = "./data/"

tuple_rank = {}

def load_stop_words():
    """
    加载停用词
    :return:
    """
    with open(os.path.join(path, "stopwords_overall.txt"), encoding="utf-8") as f:
        stopwords = f.read().split("\n")
        return stopwords

def load_stop_wordstuple():
    """
    加载停用词元组
    :return:
    """
    with open(os.path.join(path, "stopwordstpl.txt"), encoding="utf-8") as f:
        stopwordstpl = f.read().split("\n")
        return stopwordstpl

def load_feedbacks():
    """
    加载游戏内反馈
    """
    pd_all = pd.read_csv(os.path.join(path, "qiuqiu-report-2020.04.12"), sep='#')
    pd_all = shuffle(pd_all)
    # print(pd_all.head())
    print(pd_all.shape)
    pd_all = pd_all[pd.notnull(pd_all.ix[:, 18])]
    feedbacks = pd_all.ix[:, 18]
    return feedbacks

def get_feedbacks_tuple(lastFbSeg, fbSegs):
    """
    递归计算反馈分词顺序组合词频
    :param lastFbSeg:行首词
    :param fbSegs:除行首词外的内容
    :return:分词元组词频
    """
    global tuple_rank
    fbSegsLen = len(fbSegs)
    if fbSegsLen == 1: return
    if lastFbSeg is not None \
            and lastFbSeg.strip() != "" \
            and lastFbSeg not in stop_words:
        for i in range(1, fbSegsLen-1):
            # wordTpl = (lastFbSeg, fbSegs[i])
            wordTpl = lastFbSeg + "_" + fbSegs[i]
            wordTpl_rev = fbSegs[i] + "_" + lastFbSeg
            if fbSegs[i] not in stop_words \
                    and fbSegs[i].strip() != ""\
                    and fbSegs[i].strip() != lastFbSeg.strip()\
                    and wordTpl_rev not in tuple_rank\
                    and wordTpl not in stop_wordstuple\
                    and wordTpl_rev not in stop_wordstuple:
                if wordTpl not in tuple_rank:
                    tuple_rank[wordTpl] = 1
                else:
                    tuple_rank[wordTpl] += 1
    get_feedbacks_tuple(fbSegs[0], fbSegs[1:fbSegsLen])




if __name__ == "__main__":
    stop_words = load_stop_words()
    stop_wordstuple = load_stop_wordstuple()
    feedbacks = load_feedbacks()

    for feedback in feedbacks:
        fb_segs = feedback.split("|")
        get_feedbacks_tuple(None, fb_segs)

    # for word_tuple in tuple_rank:
    #     print(word_tuple)
    #     print(" rank: " + str(tuple_rank[word_tuple]))

    tuple_rank_pd = pd.DataFrame.from_dict(tuple_rank, orient='index',
                                           columns=['rank']).sort_values('rank', inplace=False, ascending=False)
    print(tuple_rank_pd.head(100))

    tuple_rank_pd.to_csv(os.path.join(path, "feedbacks_tuple_rank_len2.csv"), encoding="utf-8")