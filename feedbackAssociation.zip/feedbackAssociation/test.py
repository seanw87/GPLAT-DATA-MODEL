if __name__ == "__main__":
    tmplist = ["a", "b", "a", "c", "d"]
    tmpset = set(tmplist)
    print(tmpset)
    print(list(tmpset))